function slide_handle_left() {
	var to_change = $(".sl-img.current");
	var last      = $(".imgs img:last");
	var prev;
	if (!to_change.prev().length) {
		prev = last;
	}
	else {
		prev = to_change.prev();
	}
	to_change.removeClass('current');
	prev.addClass('current');
}

function slide_handle_right() {
	var to_change = $(".sl-img.current");
	var first     = $(".imgs img:first");
	var next;
	if (!to_change.next().length) {
		next = first;
	}
	else {
		next = to_change.next();
	}
	to_change.removeClass('current');
	next.addClass('current');
}

function bullet_handle(){
	var images    = $(".imgs").children().length;
	var i 		  = 0;
	for (i = 0; i < images; i++) {
		var bullet = $('#bull-'+(i+1).toString());
		bullet.click(function() {
			var current= $('.sl-img.current');
			var image  = $('.imgs img').eq($(this).index());
			current.removeClass('current');
			image.addClass('current');
		});
	}
}

$(document).ready(function() {
	var left_arr  = $(".sl-l");
	var right_arr = $(".sl-r");
	var slider 	  = $(".slider");
	var log_in    = $(".log-in");
	var background= $(".back");
	var modal 	  = $(".modal");
	var x		  = $(".close");
	var news_btn  = $("#news");
	var news      = $(".news");
	var contacts_btn  = $("#contacts");
	var contacts  = $(".contacts");
	var log       = $(".log");
	var reg       = $(".reg");
	var log_form  = $("#log");
	var reg_form  = $("#reg");
	var nick	  = $(".dropdown");
	var logout    = $(".logout");
	var lout 	  = $("#logout");
	var password  = $(".password");
	var openeye   = $(".openeye");
	var closeeye  = $(".closeeye");


	slider.hover(function() {
		left_arr.fadeIn('slow', function() {
			
		});
		right_arr.fadeIn('slow', function() {
			
		});
	}, function() {
		left_arr.fadeOut('slow', function() {
			
		});
		right_arr.fadeOut('slow', function() {
			
		});

	});

	left_arr.click(slide_handle_left);
	right_arr.click(slide_handle_right);
	bullet_handle();
	log_in.click(function(event) {
		background.show();
		modal.show();
	});
	background.click(function(event) {
		modal.hide();
		$(this).hide();
	});
	x.click(function(event) {
		modal.hide();
		background.hide();
	});
	// news_btn.click(function(event) {
	// 	$("body").animate({
	// 		scrollTop: news.offset().top,
	// 		},
	// 		500);
	// });

	contacts_btn.click(function(event) {
		$("body").animate({
			scrollTop: contacts.offset().top,
			},
			500);
	});

	log.click(function(event) {
		reg.addClass('small');
		$(this).removeClass('small');
		reg_form.removeClass('current');
		log_form.addClass('current');
	});

	reg.click(function(event) {
		log.addClass('small');
		$(this).removeClass('small');
		log_form.removeClass('current');
		reg_form.addClass('current');
	});
	nick.hover(function() {
		logout.slideDown(100, function() {
			
		});
	}, function() {
		/* Stuff to do when the mouse leaves the element */
	});

	lout.click(function(event) {
		$.ajax({
			url: 'logout.php'
		})
		.done(function() {
			console.log("success");
			window.location.reload();
		})
		.fail(function() {
			console.log("error");
		})
		.always(function() {
			console.log("complete");
		});
		
	});

	openeye.click(function(event) {
		password.attr('type', 'text');
		openeye.hide(0, function() {
			
		});
		closeeye.slideDown('100', function() {
			
		});
	});

	closeeye.click(function(event) {
		password.attr('type', 'password');
		closeeye.hide(0, function() {
			
		});
		openeye.slideDown(100, function() {
			
		});
			
	});

	logout.hover(function() {
		/* Stuff to do when the mouse enters the element */
	}, function() {
		$(this).hide('slow', function() {
			
		});
	});

});