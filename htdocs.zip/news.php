<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>anotherone</title>
		<link rel="stylesheet" href="css/style2.css">
		<style>
		@import url('https://fonts.googleapis.com/css?family=Lato|Roboto+Condensed|Slabo+27px|Yanone+Kaffeesatz');
		#map{
			width: 100%;
   			height: 400px;
		}
		</style>
		
	</head>
	<body>
		<div class="container">
			
			<?php include_once 'modal.php';?>
			<div class="header">
				<?php include_once 'header.php'; ?>
			</div>
			<div class="news">
				
				<?php 
				if (!isset($_GET['category'])) {
					echo '<a href="news.php?category=Anime"><div class="tab">
					<div class="thumbnail"><img src="images/image1.jpg" alt="" class="thumb"></div>
					<h1 class="hero">Anime</h1>
					</div></a>';
				}
				if (isset($_GET['category'])) {
					$category = $_GET['category'];
					require_once('db_connect.php');
    				$db = new DB_CONNECT();

    			$result = mysql_query("SELECT * FROM `news` WHERE `category`='$category'") or die(mysql_error()); 
    			echo "<div class='article-container'>";
    			echo "<a href='news.php'><img class='backbutton' src='images/backbutton.png'></a><div class='articles'>";
    			while ($row = mysql_fetch_assoc($result)){
    				echo" <h1>".$row['title']."</h1><div class='article'>".$row['text']."</div>";
    			}
    			echo "</div>";
				}
				
				?>
			</div>
		<div class="footer">
			<div class="img-link fl clk"><a href="https://vk.com/bresya"><img src="images/vklogo.png" alt=""></a></div>
			<div class="img-link fl"><img src="" alt=""></div>
			<div class="img-link fl"><img src="" alt=""></div>
			<p class="fr small"><small>All rights reserved.</small></p>
		</div>
	</div>
	<script type="text/javascript" src="bower_components/jquery/dist/jquery.js"></script>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>