<?php 
    define('DB_USER', "root"); //логин админа БД
    define('DB_PASSWORD', ""); // пароль админа БД
    define('DB_DATABASE', "anotherone"); // база данных
    define('DB_SERVER', "localhost"); // сервер 'localhost'
?>